#ifndef _GAME_OF_LIFE_H_
#define _GAME_OF_LIFE_H_

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class game_of_life {
private:
	char ALIVE = '*';
	char DEAD = ' ';
	static const unsigned int STUPACA = 60;
	static const unsigned int REDAKA = 40;
	bool _generacija[REDAKA][STUPACA];
	bool _sljedecageneracija[REDAKA][STUPACA];
	bool slucajna_vrijednost();
	bool celija_zauzeta(int i, int j);
	int rand50();

	void kutovi(int, int, int&);
	void prvi_redak(int, int, int&);
	void rubovi_lijevo_desno(int, int, int&);
	void sredina(int, int, int&);
	void zadnji_redak(int, int, int&);


public:
	game_of_life();
	void sljedeca_generacija();
	void iscrtaj();
};

#endif
